<template>
    <Login @login-success="connecterUtilisateur"/>
</template>

<script>
   import Login from '../composants/Login.vue'
   import { useRouter } from 'vue-router'
   import api from '../services/api'
import { watchEffect } from 'vue'

   const router = useRouter()

   const connecterUtilisateur = async (data) => {
     console.log('Connecté: ', data)

     try{
        const reponse = await api.post("http://localhost:3000/login")
     } catch (error) {
        console.error(error)
        alert("Erreur de connexion")
     }
    }
</script>