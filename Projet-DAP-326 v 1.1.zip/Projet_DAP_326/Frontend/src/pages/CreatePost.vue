<template>
    <PostForm titreForm="Créer un nouvel article" @handleSubmit="creerArticle" @handleCancel="cancelForm"/>
</template>

<script setup>
  import PostForm from '../composants/PostForm.vue'
  import {useRouter} from 'vue-router'
  import api from '../services/api' 

  const router = useRouter()

  const creerArticle = async (form) => {
    try {
        const reponse = await api.post('/createPost', form)
        console.log('Article créé avec succès')
        router.push('/')
    } catch (error) {
        console.error('Erreur lors de la création de l\'article :', error)
    }
  }

  const cancelForm = () => {
    router.push('/')
  }

</script>