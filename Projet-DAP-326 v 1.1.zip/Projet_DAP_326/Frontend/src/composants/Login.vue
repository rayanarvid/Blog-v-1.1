<template>
    <form class="form-article" @submit.prevent="handleLogin">
                <h2> Se Connecter </h2>
                <p class="subtitle"> Content de te revoir </p>

                <div class="alert-error">

                </div>

                <div class="form-group">
                    <label for=""> Email </label>
                    <input type="email" placeholder="tonemail@gmail.com" v-model="form.email" required>
                </div>

                <div class="form-group">
                    <label for=""> Mot de passe </label>
                    <input type="password" placeholder="******" v-model="form.password" required>
                </div>

                <div class="form-group-row">
                    <label class="checkbox"> 
                      <input type="checkbox" v-model="form.rememberMe">
                      Se souvenir de moi
                    </label>
                    <a href="#"> Mot de passe oublié ? </a>
                </div>

                <button class="btn-primary" :disabled="isLoading === false">
                    Se connecter
                </button>

                <p class="switch-auth">
                    Pas encore de compte ?
                    <a href="#"> S'inscrire </a>
                </p>
            </form>
</template>

<script setup>
   import { reactive,ref, defineEmits } from 'vue'

   const emit = defineEmits(['login-success'])

   const form = reactive({
    email: '',
    password: '',
    rememberMe: false
   })

   const isLoading = ref(false)

   const handleLogin = () => {
    isLoading.value = true
    emit('login-success', { ...form }) 
   }

</script>

<style scoped>
   .form-article {
                max-width: 500Px;
                margin: 0 auto;
                padding: 32px;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                background: #fff;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);

            }

            .form-article h2 {
                margin: 0 0 24px 0;
                font-size: 1.5rem;
            }

            .alert-error {
                padding: 10px 12px;
                background: #fef2f2;
                color: #dc2626;
                border: 1px solid #fecaca;
                border-radius: 6px;
                margin-bottom: 20px;
                font-size: 0.9rem;
            }

            .form-group {
                margin-bottom: 20px;
            }

            .form-group label {
                display: block;
                margin-bottom: 6px;
                font-weight: 500;
                color: #111;
            }

            .form-group input[type="email"],
            .form-group input[type="password"] {
                width: 100%;
                padding: 10px 12px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 1rem;
                font-family: inherit;
                box-sizing: border-box;
            }

            .form-group-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 28px;
                font-size: 0.9rem;
            }

            .checkbox {
                display: flex;
                align-items: center;
                gap: 6px;
                cursor: pointer;
                color: #374151;
            }

            .form-group-row a {
                color: rgba(18, 36, 196, 0.133);
                text-decoration: none;
            }

            .form-group-row a:hover {
                text-decoration: underline;
            }

            .btn-primary {
                padding: 10px 20px;
                border: none;
                justify-content: flex-end;
                border-radius: 6px;
                font-weight: 500;
                background: #3b82f6;
                color: white;
                cursor: pointer;
                transition: all 0.2s;
            }

            .btn-primary:hover {
                background: #2563eb;
            }

            .switch-auth {
                text-align: center;
                margin: 24px 0 0 0;
                color: #6b7280;
                font-size: 0.9rem;
            }

            .switch-auth a {
                color: #667eea;
                font-weight: 500;
                text-decoration: none;
            }

            .switch-auth a:hover {
                color: #2563eb;
            }
</style>