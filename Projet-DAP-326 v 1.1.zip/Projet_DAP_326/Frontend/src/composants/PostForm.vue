<template>
    <form  class="form-article" @submit.prevent="handleSubmit">
            <h2> {{ titreForm }} </h2>

            <div class="form-group">
                <label> Titre de l'article </label>
                <input type="text" placeholder="Ex: Comment dribbler" v-model="form.titre" required>
            </div>

            <!--<div class="form-group">
                <label> Image de couverture </label>
                <input type="file" accept="image/*" @change="handleImageChange" required>
                <small v-if="imagePreview" :style="{color : 'green'}"> Image sélectionnée </small>
                <small v-else :style="{color : 'gray'}"> JPG, PNG , 1200x600px recommandé </small>
            </div>-->

            <div class="form-group">
                <label> Categorie </label>
                <select required>
                    <option> choisir une catégorie </option>
                    <option v-for="cat in categories" :key="cat.value" :value="cat.value">
                        {{ cat }}
                    </option>
                </select>
            </div>

            <div class="form-group">
                <label> Contenu </label>
                <textarea id="contenu" placeholder="Redigez ton article ici..." v-model="form.contenu" required></textarea>
            </div>

            <div class="form-actions">
                <button type="button" class="btn-secondary" @click="handleCancel"> Annuler </button>
                <button type="submit" class="btn-primary" > Publier l'article </button>
            </div>
        </form>
</template>

<script setup>
   import {ref,reactive,computed, initCustomFormatter} from 'vue'
   import {useRouter} from 'vue-router'

   const router = useRouter()

   const props = defineProps({
    titreForm: {
        type: String,
        default: 'Créer un nouvel article'
    },
    submitLabel: {
        type: String,
        default: 'Publier'
    }
   })

   const categories = ref(['Science','Ecole','Sport','Musique', 'Informatique'])

   const emit = defineEmits(['submit', 'cancel'])

   const form = reactive({
    titre: '',
    contenu: '',
    categorie: '',
    nombrevue:0
   })

   /*const handleImageChange = (event) => {
    const file = event.target.files[0]
    if (file) {
        form.image = file
        imagePreview.value = URL.createObjectURL(file)
    }
   }*/

   const handleSubmit = () => {
    console.log('formulaire envoyé')
    emit('submit', form.value) 
   }

   const handleCancel = () => {
    alert('Formulaire annulé')
    router.push('/')
    emit('cancel')
   }
</script>

<style scoped>
   
   .form-article {
                max-width: 700px;
                margin: 0 auto;
                margin-top: 80px;
                padding: 32px;
                margin-bottom: 30px;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                background: #fff;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
            }

            .form-article h2 {
                margin: 0 0 24px 0;
                font-size: 1.5rem;
            }

            .form-group {
                margin-bottom: 20px;
            }

            .form-group label {
                display: block;
                margin-bottom: 6px;
                font-weight: 500;
                color: #111;
            }

            .form-group input[type="text"],
            .form-group input[type="file"],
            .form-group select,
            .form-group textarea {
                width: 100%;
                padding: 10px 12px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 1rem;
                font-family: inherit;
                box-sizing: border-box;
            }

            .form-group input:focus,
            .form-group select:focus,
            .form-group textarea:focus {
                outline: none;
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.1);
            }

            .form-group textarea {
                resize: vertical;
            }

            .form-group small {
                display: block;
                margin-top: 4px;
                color: #6b7280;
                font-size: 0.875rem;
            }

            .form-actions {
                display: flex;
                justify-content: flex-end;
                gap: 12px;
                margin-top: 28px; 
            }

            .btn-primary, .btn-secondary {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s;
            }

            .btn-primary {
                background: #3b82f6;
                color: white;
            }

            .btn-primary:hover {
                background: #2563eb;
            }

            .btn-secondary {
                background: #f3f4f6;
                color: #111;
            }

            .btn-secondary:hover {
                background: #e5e7eb;
            }
</style>