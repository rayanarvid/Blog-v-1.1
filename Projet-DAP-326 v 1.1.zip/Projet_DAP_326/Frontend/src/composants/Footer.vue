<template>
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-section">
        <div class="logo">
          <img src="" alt="Blog Logo" class="logo-img" />
          <span class="logo-text">BLOG</span>
        </div>
        <p class="description">Partagez vos idées et découvrez des articles inspirants.</p>
      </div>

      <div class="footer-section">
        <h3>Liens utiles</h3>
        <ul>
          <li><a href="#">Catégorie</a></li>
          <li><a href="#">Créer</a></li>
          <li><a href="#">Profil</a></li>
        </ul>
      </div>

      <div class="footer-section">
        <h3>Légal</h3>
        <ul>
          <li><a href="#">Mentions légales</a></li>
          <li><a href="#">Politique de confidentialité</a></li>
          <li><a href="#">CGU</a></li>
        </ul>
      </div>

      <div class="footer-section">
        <h3>Suivez-nous</h3>
        <div class="social-links">
          <a href="#" class="social-link">Twitter</a>
          <a href="#" class="social-link">LinkedIn</a>
          <a href="#" class="social-link">GitHub</a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; 2026 Blog - Tous droits réservés</p>
    </div>
  </footer>
</template>

<script setup>

</script>

<style scoped>
.footer {
  background: #f8f9fa;
  border-top: 1px solid #dee2e6;
  margin-top: auto;
}

.footer-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 3rem 1rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
}

.logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.logo-img {
  width: 32px;
  height: 32px;
}

.logo-text {
  font-size: 1.5rem;
  font-weight: bold;
  color: #000;
}

.description {
  color: #6c757d;
  line-height: 1.5;
}

.footer-section h3 {
  font-size: 1.1rem;
  margin-bottom: 1rem;
  color: #212529;
}

.footer-section ul {
  list-style: none;
  padding: 0;
}

.footer-section li {
  margin-bottom: 0.5rem;
}

.footer-section a {
  text-decoration: none;
  color: #495057;
}

.footer-section a:hover {
  color: #0d6efd;
}

.social-links {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.social-link {
  text-decoration: none;
  color: #495057;
}

.social-link:hover {
  color: #0d6efd;
}

.footer-bottom {
  text-align: center;
  padding: 1.5rem;
  border-top: 1px solid #dee2e6;
  color: #6c757d;
  font-size: 0.875rem;
}
</style>