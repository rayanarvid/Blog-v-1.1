<template>
  <nav class="navbar">
    <div class="nav-container">
      <a class="logo" href="#"> BLOG </a>
      
      <div class="nav-links">
          <RouterLink to="/"> Catégorie </RouterLink>
          <RouterLink to="/create"> Créer </RouterLink>
          <RouterLink to="/"> Accueil </RouterLink>
      </div>
      
      <div class="nav-action">
        <button class="btn-outline"> Se connecter </button>
        <button class="btn-primary"> S'inscrire </button>
      </div>

     <div class="search-group">
          <input type="search" placeholder="Rechercher un article">
          <button class="btn-secondary"> Rechercher </button>
    </div>
    </div>
  </nav>
</template>

<script setup></script>

<style scoped>
  .navbar {
    margin: 0;
    background: white;
    top: 0;
    left: 0;
    border: 1px solid #dee2e6;
    padding: 1rem 0;
    width: 100%;
    position: fixed;
    z-index: 1000;
  }

  .nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 2rem;
  }

  .logo {
    font-size: 1.5rem;
    font-weight: bold;
    text-decoration: none;
    color: #000;
  }

  .nav-links {
    display: flex;
    gap: 1.5rem;
  }

  .nav-links a {
    text-decoration: none;
    color: #495057;
  }

  .nav-links a:hover {
    color: #0d6efd
  }

    .nav-action {
        display: flex;
        gap: 0.5rem;
        align-items: center;
    }

    button {
        padding: 0.375rem 0.75rem;
        border-radius: 0.375rem;
        cursor: pointer;
        font-size: 1rem;
    }

    .btn-outline {
        border: 1px solid #0d6efd;
        background: transparent;
        color: #0d6efd;
    }

    .btn-primary {
        background: #0d6efd;
        border: 1px solid #0d6efd;
        color: white;
    }

    .btn-secondary {
        background: #6c757d;
        border: 1px solid #6c757d;
        color: white;
    }

    .btn-outline:hover {
        background: #0d6efd;
        color: white;
    }

    .btn-primary:hover {
        background: #0b5ed7;
    }

    .btn-secondary:hover {
        background: #5c636a;
    }

    .search-group {
        display: flex;
        gap: 0;
    }

    .search-group input {
        padding: 0.375rem 0.75rem;
        border: 1px solid #ced4da;
        border-radius: 0.375rem 0 0 0.375rem;
        width: 200px;
    }

    .search-group button {
        border-radius: 0 0.375rem 0.375rem 0;
        border-left: none;
    }

</style>
