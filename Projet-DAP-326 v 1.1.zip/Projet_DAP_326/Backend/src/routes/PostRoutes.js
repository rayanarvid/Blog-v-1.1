const express = require('express');
const router = express.Router();
const controller = require('../controllers/PostController');


router.post('/createPost', controller.createPost);

module.exports = router;