<template>
    <main class="profile-page">
  <div class="profile-container">
    
    <!-- Bannière de couverture -->
    <div class="profile-cover">
      <div class="cover-edit-btn">
        <button class="btn-edit-cover">🖌️ Changer la couverture</button>
      </div>
    </div>

    <!-- Zone profil (avatar + infos) -->
    <div class="profile-header">
      <div class="profile-avatar-wrapper">
        <div class="profile-avatar">
          <span class="avatar-emoji">👤</span>
        </div>
        <button class="btn-edit-avatar">✎</button>
      </div>
      
      <div class="profile-info">
        <h1>Jean Dupont</h1>
        <p class="profile-bio">Passionné de technologie et d'écriture. Je partage mes découvertes et mes réflexions sur le monde du développement.</p>
        
        <div class="profile-stats">
          <div class="stat">
            <span class="stat-value">24</span>
            <span class="stat-label">Articles</span>
          </div>
          <div class="stat">
            <span class="stat-value">156</span>
            <span class="stat-label">Abonnés</span>
          </div>
          <div class="stat">
            <span class="stat-value">89</span>
            <span class="stat-label">Abonnements</span>
          </div>
        </div>

        <div class="profile-meta">
          <span class="meta-item">📅 Membre depuis mars 2024</span>
          <span class="meta-item">📍 Paris, France</span>
          <span class="meta-item">🔗 <a href="#">jean-dupont.blog</a></span>
        </div>

        <div class="profile-actions">
          <button class="btn-primary btn-sm">✏️ Modifier le profil</button>
          <button class="btn-secondary btn-sm">⚙️ Paramètres</button>
        </div>
      </div>
    </div>

    <!-- Onglets navigation profil -->
    <div class="profile-tabs">
      <button class="tab-btn active">📝 Mes articles</button>
      <button class="tab-btn">❤️ Favoris</button>
      <button class="tab-btn">📌 Archivés</button>
    </div>

    <!-- Contenu des articles -->
    <div class="profile-content">
      
      <!-- Carte article 1 -->
      <div class="article-card">
        <div class="article-card-header">
          <span class="article-category">Technologie</span>
          <span class="article-date">12 avril 2026</span>
        </div>
        <h3 class="article-title">Les tendances tech à suivre en 2026</h3>
        <p class="article-excerpt">Découvrez les innovations qui vont marquer cette année : IA générative, web3, et nouvelles approches de développement...</p>
        <div class="article-card-footer">
          <div class="article-stats">
            <span>❤️ 34</span>
            <span>💬 12</span>
          </div>
          <a href="#" class="article-read-more">Lire la suite →</a>
        </div>
      </div>

      <!-- Carte article 2 -->
      <div class="article-card">
        <div class="article-card-header">
          <span class="article-category">Écriture</span>
          <span class="article-date">5 avril 2026</span>
        </div>
        <h3 class="article-title">Comment trouver l'inspiration au quotidien</h3>
        <p class="article-excerpt">Astuces et exercices pratiques pour développer votre créativité et ne plus jamais manquer d'idées...</p>
        <div class="article-card-footer">
          <div class="article-stats">
            <span>❤️ 28</span>
            <span>💬 8</span>
          </div>
          <a href="#" class="article-read-more">Lire la suite →</a>
        </div>
      </div>

      <!-- Carte article 3 -->
      <div class="article-card">
        <div class="article-card-header">
          <span class="article-category">Productivité</span>
          <span class="article-date">28 mars 2026</span>
        </div>
        <h3 class="article-title">Ma méthode pour gérer mon temps efficacement</h3>
        <p class="article-excerpt">Retour d'expérience sur les outils et routines qui ont transformé ma façon de travailler...</p>
        <div class="article-card-footer">
          <div class="article-stats">
            <span>❤️ 47</span>
            <span>💬 15</span>
          </div>
          <a href="#" class="article-read-more">Lire la suite →</a>
        </div>
      </div>

    </div>
  </div>
</main>
</template>

<script setup></script>

<style scoped>
   /* Page profil */
.profile-page {
  min-height: calc(100vh - 200px);
  background: #F8F6F2;
}

.profile-container {
  max-width: 1000px;
  margin: 0 auto;
  background: #FFFFFF;
  border-radius: 28px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
  overflow: hidden;
  margin: 2rem auto;
}

/* Bannière de couverture */
.profile-cover {
  height: 180px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
}

.cover-edit-btn {
  position: absolute;
  bottom: 1rem;
  right: 1rem;
}

.btn-edit-cover {
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 0.4rem 1rem;
  border-radius: 40px;
  font-size: 0.75rem;
  color: white;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
}

.btn-edit-cover:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* Header profil */
.profile-header {
  padding: 0 2rem 1.5rem 2rem;
  position: relative;
  margin-top: -50px;
}

.profile-avatar-wrapper {
  position: relative;
  display: inline-block;
  margin-bottom: 1rem;
}

.profile-avatar {
  width: 100px;
  height: 100px;
  background: linear-gradient(135deg, #8B5CF6, #6D28D9);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 4px solid #FFFFFF;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.avatar-emoji {
  font-size: 3rem;
}

.btn-edit-avatar {
  position: absolute;
  bottom: 5px;
  right: 5px;
  width: 32px;
  height: 32px;
  background: #FFFFFF;
  border: 1px solid #E2E8F0;
  border-radius: 50%;
  cursor: pointer;
  font-size: 0.9rem;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-edit-avatar:hover {
  background: #F1F5F9;
  transform: scale(1.05);
}

/* Infos profil */
.profile-info {
  margin-top: 0.5rem;
}

.profile-info h1 {
  font-size: 1.8rem;
  font-weight: 700;
  color: #1A1A2E;
  margin: 0 0 0.5rem 0;
  letter-spacing: -0.3px;
}

.profile-bio {
  font-size: 0.9rem;
  color: #64748B;
  line-height: 1.5;
  max-width: 600px;
  margin-bottom: 1.2rem;
}

/* Stats */
.profile-stats {
  display: flex;
  gap: 2rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
}

.stat {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-value {
  font-size: 1.3rem;
  font-weight: 700;
  color: #1A1A2E;
}

.stat-label {
  font-size: 0.7rem;
  color: #94A3B8;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* Métadonnées */
.profile-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 1.2rem;
  margin-bottom: 1.5rem;
}

.meta-item {
  font-size: 0.8rem;
  color: #64748B;
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
}

.meta-item a {
  color: #8B5CF6;
  text-decoration: none;
}

.meta-item a:hover {
  text-decoration: underline;
}

/* Boutons action */
.profile-actions {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.btn-sm {
  padding: 0.5rem 1.2rem;
  font-size: 0.8rem;
}

/* Onglets */
.profile-tabs {
  display: flex;
  gap: 0.5rem;
  padding: 0 2rem;
  border-bottom: 1px solid #F0F2F5;
  background: #FFFFFF;
}

.tab-btn {
  background: none;
  border: none;
  padding: 1rem 1.2rem;
  font-size: 0.85rem;
  font-weight: 600;
  color: #64748B;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
  position: relative;
}

.tab-btn:hover {
  color: #8B5CF6;
}

.tab-btn.active {
  color: #8B5CF6;
}

.tab-btn.active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
  height: 2px;
  background: #8B5CF6;
  border-radius: 2px;
}

/* Contenu profil (articles) */
.profile-content {
  padding: 1.5rem 2rem 2rem 2rem;
}

/* Cartes articles */
.article-card {
  background: #F8FAFE;
  border-radius: 20px;
  padding: 1.5rem;
  margin-bottom: 1.2rem;
  transition: all 0.2s ease;
  border: 1px solid rgba(0, 0, 0, 0.03);
}

.article-card:hover {
  background: #FFFFFF;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  border-color: rgba(139, 92, 246, 0.1);
}

.article-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.8rem;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.article-category {
  font-size: 0.7rem;
  font-weight: 600;
  color: #8B5CF6;
  background: #F3E8FF;
  padding: 0.2rem 0.8rem;
  border-radius: 20px;
}

.article-date {
  font-size: 0.7rem;
  color: #94A3B8;
}

.article-title {
  font-size: 1.1rem;
  font-weight: 700;
  color: #1A1A2E;
  margin: 0 0 0.5rem 0;
  letter-spacing: -0.2px;
}

.article-excerpt {
  font-size: 0.85rem;
  color: #64748B;
  line-height: 1.5;
  margin-bottom: 1rem;
}

.article-card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.8rem;
}

.article-stats {
  display: flex;
  gap: 1rem;
}

.article-stats span {
  font-size: 0.75rem;
  color: #94A3B8;
}

.article-read-more {
  font-size: 0.8rem;
  font-weight: 600;
  color: #8B5CF6;
  text-decoration: none;
  transition: all 0.2s ease;
}

.article-read-more:hover {
  gap: 0.5rem;
  color: #6D28D9;
}

/* Responsive */
@media (max-width: 768px) {
  .profile-container {
    margin: 1rem;
    border-radius: 20px;
  }
  
  .profile-header {
    padding: 0 1.5rem 1.2rem 1.5rem;
  }
  
  .profile-info h1 {
    font-size: 1.4rem;
  }
  
  .profile-stats {
    gap: 1rem;
  }
  
  .profile-meta {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .profile-tabs {
    padding: 0 1rem;
  }
  
  .tab-btn {
    padding: 0.8rem 1rem;
    font-size: 0.8rem;
  }
  
  .profile-content {
    padding: 1rem 1.5rem 1.5rem 1.5rem;
  }
  
  .article-card {
    padding: 1rem;
  }
}

@media (max-width: 480px) {
  .profile-cover {
    height: 120px;
  }
  
  .profile-avatar {
    width: 80px;
    height: 80px;
  }
  
  .avatar-emoji {
    font-size: 2.5rem;
  }
  
  .profile-stats {
    justify-content: space-between;
  }
  
  .profile-actions {
    flex-direction: column;
    width: 100%;
  }
  
  .btn-sm {
    text-align: center;
  }
}
</style>