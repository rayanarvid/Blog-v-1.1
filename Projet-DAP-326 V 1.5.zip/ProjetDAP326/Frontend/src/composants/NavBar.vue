<template>
  <nav class="navbar">
    <div class="nav-container">
      <a class="logo" href="#"> BLOG </a>
      
      <div class="nav-links">
          <RouterLink to="/Categories"> Catégorie </RouterLink>
          <RouterLink to="/create" @click="handleClick"> Créer </RouterLink>
          <RouterLink to="/"> Accueil </RouterLink>
      </div>
      
      <div class="nav-action">
        <button class="btn-outline" @click="Login"> Se connecter </button>
        <button class="btn-primary" @click="signIn"> S'inscrire </button>
      </div>

     <div class="search-group">
          <input type="search" placeholder="Rechercher un article">
          <button class="btn-secondary"> Rechercher </button>
    </div>
    </div>
  </nav>

  <div v-if="showPopup" class="overlay">
    <div class="popup">
      <span class="close" @click="showPopup = false"> X </span>
      <h3> Veillez vous connectez avant de créer un article </h3>
    </div>
  </div>
</template>

<script setup>
   import { useRouter } from 'vue-router'
   import {ref} from 'vue'

   const isConnected = ref(false)
   const showPopup = ref(false)

   const router = useRouter();

   const Login = () => {
    router.push('/login');
   }

   const signIn = () => {
    router.push('/signIn')
   }

   //Vérifie si l'utilisateur est connecté
   const handleClick = (e) => {
    if (!isConnected.value) {
      e.preventDefault()
      showPopup.value = true
    }
   }
</script>

<style scoped>
  .navbar {
    margin: 0;
    background: rgba(10, 10, 20, 0.85);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
    backdrop-filter: blur(16px);
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    top: 0;
    left: 0;
    border: 1px solid #dee2e6;
    padding: 0.9rem 0;
    width: 100%;
    position: fixed;
    z-index: 1000;
  }

  .nav-container {
    max-width: 1280px;
    margin: 0 auto;
    padding: 0 2rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1.5rem;
    flex-wrap: wrap;
  }

  .logo {
    font-size: 1.5rem;
    font-weight: 700;
    letter-spacing: -0.3px;
    background: linear-gradient(135deg, #FFFFFF 0%, #A78BFA 100%);
    background-clip: text;
    -webkit-background-clip: text;
    text-decoration: none;
    color: transparent;
    transition: opacity 0.25s ease;
  }

  .logo:hover {
    opacity: 0.85;
  }

  .nav-links {
    display: flex;
    gap: 2.2rem;
    align-items: center;
    flex-wrap: wrap;
  }

  .nav-links a {
    text-decoration: none;
    color: #E2E8F0;
    font-weight: 450;
    font-size: 0.9rem;
    transition: all 0.2s ease;
    padding: 0.4rem 0;
    letter-spacing: -0.2px;
    position: relative;
  }

  .nav-links a:hover {
    color: #C4B5FD;
  }

  .nav-links a::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 1.5px;
    background: linear-gradient(90deg, #A78BFA, #CAB5FD);
    transition: width 0.2s cubic-bezier(0.2, 0.9, 0.4, 1.1);
    border-radius: 2px;
  }

  .nav-links a:hover::after {
    width: 100%;
  }

    .nav-action {
        display: flex;
        gap: 0.8rem;
        align-items: center;
    }

    button {
        padding: 0.375rem 0.75rem;
        border-radius: 0.375rem;
        cursor: pointer;
        font-size: 1rem;
    }

    .btn-outline {
        border: 1.5px solid rgb(255, 255, 225, 0.2);
        padding: 0.55rem 1.4rem;
        border-radius: 48px;
        font-weight: 500;
        font-size: 0.85rem;
        background: transparent;
        color: #E2E8F0;
        cursor: pointer;
        transition: all 0.25s ease;
        font-family: inherit;
        letter-spacing: -0.2px;
        backdrop-filter: blur(4px);
    }

    .btn-primary {
        padding: 0.55rem 1.4rem;
        border-radius: 48px;
        font-weight: 500;
        font-size: 0.85rem;
        background: linear-gradient(135deg, #8B5CF6, #6D28D9);
        border: none;
        color: white;
        cursor: pointer;
        transition: all 0.25s ease;
        font-family: inherit;
        letter-spacing: -0.2px;
        box-shadow: 0 4px 12px rgba(139, 92, 246, 0.25);
        position: relative;
        overflow: hidden;
    }

    .btn-primary::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: left 0.5s ease;
    }

    .btn-primary:hover::before {
      left: 100%;
    }

    .btn-secondary {
        background: #6c757d;
        border: 1px solid #6c757d;
        color: white;
    }

    .btn-outline:hover {
      border-color: #A78BFA;
        color: #C4B5FD;
        background: rgb(167, 139, 250, 0.08);
        transform: translateY(-1px);
    }

    .btn-primary:hover {
        background: linear-gradient(135deg, #7C3AED, #5B21B6);
        transform: translateY(-1px);
        box-shadow: 0 6px 18px rgb(139, 92, 246, 0.35);
    }

    .btn-secondary:hover {
        background: #5c636a;
    }

    .search-group {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        background: rgba(30, 30, 45, 0.6);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 48px;
        padding: 0.2rem 0.2rem 0.2rem 1rem;
        transition: all 0.25s ease;
    }

    .search-group:focus-within {
      border-color: #8B5CF6;
      background: rgba(40, 40, 60, 0.8);
      box-shadow: 0 0 0 3px rgb(139, 92, 246, 0.15);
    }

    .search-group input {
        border: none;
        background: transparent;
        outline: none;
        font-size: 0.85rem;
        padding: 0.55rem 0;
        width: 160px;
        font-family: inherit;
        color: #F1F5F9;
    }

    .search-group input::placeholder {
      color: #94a3b8;
      font-weight: 400;
    }

    .search-group button {
        border-radius: 40px;
        background: rgba(139, 92, 246, 0.9);
        border: none;
        padding: 0.5rem 1.2rem;
        font-weight: 500;
        font-size: 0.8rem;
        color: white;
        cursor: pointer;
        transition: all 0.2s ease;
        font-family: inherit;
        backdrop-filter: blur(4px);
    }

    .search-group button:hover {
      background: #8B5CF6;
      transform: scale(0.97);
    }

    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(10, 10, 20, 0.75);
      backdrop-filter: blur(8px);
      display: flex;
      justify-content: center;
      align-items: center;
      animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    .popup {
      background: #FFFFFF;
      padding: 2rem 2rem 1.8rem 2rem;
      border-radius: 28px;
      width: 300px;
      position: relative;
      text-align: center;
      box-shadow: 0 20px 40px -12px rgba(0, 0, 0, 0.3);
      animation: slideUp 0.35s cubic-bezier(0.2, 0.9, 0.4, 1.1);
      border: 1px solid rgba(0, 0, 0, 0.05);
    }

    @keyframes slideUp {
      from {
        transform: translateY(30px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .close {
      position: absolute;
      top: 1.2rem;
      right: 1.2rem;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      font-weight: 400;
      color: #94A3B8;
      transition: all 0.2s ease;
      border-radius: 40px;
      cursor: pointer;
    }

    .close:hover {
      background: #FEE2E2;
      color: #EF4444;
      transform: scale(1.05);
    }

    .popup h3 {
      font-size: 1.2rem;
      font-weight: 600;
      color: #1A1A2E;
      margin: 0.5rem 0 1.5rem 0;
      line-height: 1.4;
      padding-right: 1rem;
    }

</style>
