<template>
    <div class="cardre">
         <!-- <img :src="imageSrc" alt="Image de l'article" class="card-image" v-if="imageSrc"/> -->    

      <div class="card-content">
        <h5> {{ titre }} </h5>
        <p> {{ contenu }} </p>
      </div>

      <div class="card-footer">
        <button class="btn-like"> Liker </button>
        <button class="btn-read"> Lire la suite </button>
      </div>
    </div>
</template>

<script setup>
  
  defineProps({
    titre: String,
    contenu: String,
    auteur: String,
    categorie: String,
    nombrevue: Number
  })

</script>

<style scoped>
  
  .card {
  background: #FFFFFF;
  border-radius: 24px;
  overflow: hidden;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
  border: 1px solid rgba(0, 0, 0, 0.04);
  margin-bottom: 1.5rem;
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 30px -12px rgba(0, 0, 0, 0.12);
  border-color: rgba(139, 92, 246, 0.15);
}

/* Contenu de la carte */
.card-content {
  padding: 1.5rem;
}

.card-content h5 {
  font-size: 1.25rem;
  font-weight: 700;
  color: #1A1A2E;
  margin: 0 0 0.75rem 0;
  letter-spacing: -0.3px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.card-content p {
  font-size: 0.9rem;
  color: #475569;
  line-height: 1.5;
  margin: 0;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* Footer de la carte */
.card-footer {
  padding: 1rem 1.5rem 1.5rem 1.5rem;
  display: flex;
  gap: 0.8rem;
  border-top: 1px solid #F0F2F5;
  background: #FAFBFD;
}

/* Boutons */
.btn-like {
  background: transparent;
  border: 1.5px solid #E2E8F0;
  padding: 0.6rem 1.2rem;
  border-radius: 40px;
  font-weight: 600;
  font-size: 0.8rem;
  color: #475569;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-like::before {
  content: '♡';
  font-size: 1rem;
  transition: all 0.2s ease;
}

.btn-like:hover {
  border-color: #F43F5E;
  color: #F43F5E;
  background: #FFF1F2;
  transform: translateY(-1px);
}

.btn-like:hover::before {
  content: '❤️';
  color: #F43F5E;
}

.btn-like:active {
  transform: translateY(0);
}

.btn-read {
  background: transparent;
  border: 1.5px solid #E2E8F0;
  padding: 0.6rem 1.2rem;
  border-radius: 40px;
  font-weight: 600;
  font-size: 0.8rem;
  color: #475569;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: inherit;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.btn-read::after {
  content: '→';
  font-size: 0.9rem;
  transition: transform 0.2s ease;
}

.btn-read:hover {
  border-color: #8B5CF6;
  color: #8B5CF6;
  background: #F8F4FF;
  transform: translateY(-1px);
}

.btn-read:hover::after {
  transform: translateX(4px);
}

.btn-read:active {
  transform: translateY(0);
}

/* Version like actif (si besoin) */
.btn-like.active {
  border-color: #F43F5E;
  color: #F43F5E;
  background: #FFF1F2;
}

.btn-like.active::before {
  content: '❤️';
}

/* Grille de cartes (si plusieurs cartes) */
.cards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 1.8rem;
  padding: 1rem 0;
}

/* Responsive */
@media (max-width: 680px) {
  .card-content {
    padding: 1.2rem;
  }
  
  .card-footer {
    padding: 0.8rem 1.2rem 1.2rem 1.2rem;
    flex-wrap: wrap;
  }
  
  .btn-like,
  .btn-read {
    flex: 1;
    text-align: center;
    justify-content: center;
  }
}
</style>