<template>
    <main class="categories-page">
  <div class="categories-container">
    
    <!-- En-tête de la page -->
    <div class="page-header">
      <h1>Catégories</h1>
      <p>Explorez les articles par thème et trouvez l'inspiration</p>
    </div>

    <!-- Grille des catégories -->
    <div class="categories-grid">
      
      <!-- Catégorie 1 -->
      <div class="category-card">
        <div class="category-icon">💻</div>
        <h3>Technologie</h3>
        <p>Actualités tech, logiciels, innovations et tendances numériques</p>
        <span class="article-count">24 articles</span>
        <a href="#" class="category-link">Explorer →</a>
      </div>

      <!-- Catégorie 2 -->
      <div class="category-card">
        <div class="category-icon">✍️</div>
        <h3>Écriture</h3>
        <p>Conseils d'écriture, inspiration, techniques et partages d'expérience</p>
        <span class="article-count">18 articles</span>
        <a href="#" class="category-link">Explorer →</a>
      </div>

      <!-- Catégorie 3 -->
      <div class="category-card">
        <div class="category-icon">🎨</div>
        <h3>Créativité</h3>
        <p>Design, arts visuels, inspiration créative et projets personnels</p>
        <span class="article-count">15 articles</span>
        <a href="#" class="category-link">Explorer →</a>
      </div>

      <!-- Catégorie 4 -->
      <div class="category-card">
        <div class="category-icon">🚀</div>
        <h3>Productivité</h3>
        <p>Méthodes de travail, outils, routines et astuces pour être efficace</p>
        <span class="article-count">32 articles</span>
        <a href="#" class="category-link">Explorer →</a>
      </div>

      <!-- Catégorie 5 -->
      <div class="category-card">
        <div class="category-icon">🌱</div>
        <h3>Développement perso</h3>
        <p>Bien-être, mindset, formation continue et objectifs personnels</p>
        <span class="article-count">21 articles</span>
        <a href="#" class="category-link">Explorer →</a>
      </div>

      <!-- Catégorie 6 -->
      <div class="category-card">
        <div class="category-icon">📖</div>
        <h3>Lectures</h3>
        <p>Recommandations de livres, résumés et avis littéraires</p>
        <span class="article-count">14 articles</span>
        <a href="#" class="category-link">Explorer →</a>
      </div>

    </div>
  </div>
</main>
</template>

<script setup></script>

<style scoped>
   /* Page catégories */
.categories-page {
  min-height: calc(100vh - 200px);
  padding: 3rem 2rem;
}

.categories-container {
  max-width: 1280px;
  margin: 0 auto;
}

/* En-tête de page */
.page-header {
  text-align: center;
  margin-bottom: 3rem;
}

.page-header h1 {
  font-size: 2.2rem;
  font-weight: 800;
  color: #1A1A2E;
  margin-bottom: 0.75rem;
  letter-spacing: -0.02em;
  position: relative;
  display: inline-block;
}

.page-header h1::after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
  width: 60px;
  height: 3px;
  background: linear-gradient(90deg, #8B5CF6, #C4B5FD);
  border-radius: 3px;
}

.page-header p {
  font-size: 1rem;
  color: #64748B;
  margin-top: 1.2rem;
}

/* Grille des catégories */
.categories-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 2rem;
}

/* Carte catégorie */
.category-card {
  background: #FFFFFF;
  border-radius: 24px;
  padding: 1.8rem;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
  border: 1px solid rgba(0, 0, 0, 0.04);
  position: relative;
  overflow: hidden;
}

.category-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 20px 30px -12px rgba(0, 0, 0, 0.12);
  border-color: rgba(139, 92, 246, 0.15);
}

/* Décoration de fond au hover */
.category-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, #8B5CF6, #C4B5FD);
  transform: scaleX(0);
  transition: transform 0.3s ease;
}

.category-card:hover::before {
  transform: scaleX(1);
}

/* Icône */
.category-icon {
  font-size: 2.8rem;
  margin-bottom: 1rem;
  display: inline-block;
}

/* Titre catégorie */
.category-card h3 {
  font-size: 1.3rem;
  font-weight: 700;
  color: #1A1A2E;
  margin: 0 0 0.75rem 0;
  letter-spacing: -0.3px;
}

/* Description */
.category-card p {
  font-size: 0.85rem;
  color: #64748B;
  line-height: 1.5;
  margin-bottom: 1.2rem;
}

/* Nombre d'articles */
.article-count {
  display: inline-block;
  font-size: 0.7rem;
  font-weight: 600;
  color: #8B5CF6;
  background: #F3E8FF;
  padding: 0.25rem 0.8rem;
  border-radius: 20px;
  margin-bottom: 1rem;
}

/* Lien explorer */
.category-link {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  font-weight: 600;
  color: #4F46E5;
  text-decoration: none;
  transition: all 0.2s ease;
}

.category-link:hover {
  gap: 0.8rem;
  color: #6D28D9;
}

/* Responsive */
@media (max-width: 768px) {
  .categories-page {
    padding: 2rem 1.5rem;
  }
  
  .page-header h1 {
    font-size: 1.8rem;
  }
  
  .categories-grid {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
  
  .category-card {
    padding: 1.5rem;
  }
}

@media (max-width: 480px) {
  .categories-page {
    padding: 1.5rem 1rem;
  }
  
  .page-header h1 {
    font-size: 1.5rem;
  }
  
  .page-header p {
    font-size: 0.85rem;
  }
}
</style>