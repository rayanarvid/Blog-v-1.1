<template>
    
    <div class="page-home">
    

    <main class="container">
      <!-- Section Hero -->
      <section class="hero">
        <div class="hero-content">
          <h1> Partage tes idées au monde </h1>
          <p class="hero-subtitle">
            Crée, publie et découvre des articles inspirants. Rejoins une communauté de passionnés.
          </p>
          <div class="hero-actions">
            <RouterLink to="/create" class="btn-primary">
              Créer un article
            </RouterLink>
            <RouterLink to="/" class="btn-secondary">
              Explorer
            </RouterLink>
          </div>
        </div>
      </section>

      <!-- Section Articles récents -->
      <section class="section-articles">
        <h2>Articles récents</h2>
        <div class="grid-articles">
          <div v-for="article in articles" :key="article.id" class="card-article">
            <PostCard :titre="article.titre" :contenu="article.extrait" :auteur="article.auteur" :categorie="article.categorie" :nombrevue="article.nombrevue"/>
          </div>
        </div>
      </section>

      <!-- Section CTA -->
      <section class="cta">
        <h2>Prêt à écrire ?</h2>
        <p>Lance-toi et partage ton premier article avec la communauté.</p>
        <RouterLink to="/create" class="btn-primary">Commencer</RouterLink>
      </section>
    </main>

  </div>
</template>

<script setup>
   import { ref } from 'vue'
   import PostCard from '../composants/PostCard.vue'
   
       // Données de test - remplace par ton appel API
     const articles = ref([
       {
         id: 1,
         titre: 'Comment Vue 3 a changé ma façon de coder',
         extrait: 'La Composition API est une révolution. Voici pourquoi je ne reviendrai jamais en arrière...',
         auteur: 'Sarah K.',
         categorie: 'Dev',
          nombrevue: 120
       },
       {
         id: 2,
         titre: 'Design minimaliste : moins mais mieux',
         extrait: '3 principes pour créer des interfaces épurées qui convertissent vraiment...',
         auteur: 'Marc D.',
         categorie: 'Design',
          nombrevue: 85
       },
       {
         id: 3,
         titre: 'Mon setup télétravail en 2026',
         extrait: 'Chaise, écran, clavier : mon guide complet après 4 ans de remote...',
         auteur: 'Lina T.',
         categorie: 'Lifestyle',
          nombrevue: 200
       }
     ])

     
</script>

<style scoped>
  .page-home {
  min-height: 100vh;
}

.container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Hero */
.hero {
  background: linear-gradient(135deg, #F8F6F2 0%, #F0EDE5 100%);
  border-radius: 32px;
  margin: 2rem auto;
  margin-top: 2rem;
  max-width: 900px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
}

/* Éléments décoratifs */
.hero::before {
  content: '✍️';
  position: absolute;
  font-size: 8rem;
  opacity: 0.06;
  bottom: -20px;
  right: -20px;
  pointer-events: none;
  transform: rotate(-10deg);
}

.hero::after {
  content: '✨';
  position: absolute;
  font-size: 5rem;
  opacity: 0.08;
  top: -20px;
  left: -20px;
  pointer-events: none;
}

/* Contenu de la hero */
.hero-content {
  text-align: center;
  padding: 3.5rem 2rem;
  position: relative;
  z-index: 1;
}

/* Titre principal */
.hero-content h1 {
  font-size: 2.8rem;
  font-weight: 800;
  margin: 0 0 1rem 0;
  background: linear-gradient(135deg, #1A1A2E 0%, #4F46E5 60%, #8B5CF6 100%);
  background-clip: text;
  -webkit-background-clip: text;
  color: transparent;
  letter-spacing: -0.02em;
  line-height: 1.2;
}

/* Sous-titre */
.hero-subtitle {
  font-size: 1.05rem;
  color: #475569;
  line-height: 1.6;
  max-width: 520px;
  margin: 0 auto 2rem auto;
  font-weight: 450;
}

/* Groupe d'actions */
.hero-actions {
  display: flex;
  gap: 1.2rem;
  justify-content: center;
  flex-wrap: wrap;
}

/* Bouton principal (Créer un article) */
.btn-primary {
  background: linear-gradient(135deg, #8B5CF6, #6D28D9);
  border: none;
  padding: 0.85rem 2rem;
  border-radius: 48px;
  font-weight: 600;
  font-size: 0.9rem;
  color: white;
  cursor: pointer;
  transition: all 0.25s ease;
  font-family: inherit;
  letter-spacing: -0.2px;
  box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  text-decoration: none;
}

.btn-primary::before {
  content: '✏️';
  font-size: 1rem;
  transition: transform 0.2s ease;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #7C3AED, #5B21B6);
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(139, 92, 246, 0.4);
}

.btn-primary:hover::before {
  transform: rotate(-5deg);
}

.btn-primary:active {
  transform: translateY(0);
}

/* Bouton secondaire (Explorer) */
.btn-secondary {
  background: rgba(255, 255, 255, 0.7);
  border: 1.5px solid #E2E8F0;
  padding: 0.85rem 2rem;
  border-radius: 48px;
  font-weight: 600;
  font-size: 0.9rem;
  color: #4F46E5;
  cursor: pointer;
  transition: all 0.25s ease;
  font-family: inherit;
  letter-spacing: -0.2px;
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  text-decoration: none;
}

.btn-secondary::before {
  content: '🔍';
  font-size: 0.9rem;
  transition: transform 0.2s ease;
}

.btn-secondary:hover {
  border-color: #8B5CF6;
  background: white;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.btn-secondary:hover::before {
  transform: scale(1.1);
}

.btn-secondary:active {
  transform: translateY(0);
}

/* Responsive */
@media (max-width: 680px) {
  .hero {
    margin: 1rem;
    border-radius: 24px;
  }
  
  .hero-content {
    padding: 2.5rem 1.5rem;
  }
  
  .hero-content h1 {
    font-size: 1.8rem;
  }
  
  .hero-subtitle {
    font-size: 0.9rem;
    padding: 0 0.5rem;
  }
  
  .hero-actions {
    gap: 0.8rem;
  }
  
  .btn-primary,
  .btn-secondary {
    padding: 0.7rem 1.5rem;
    font-size: 0.85rem;
  }
}

@media (max-width: 480px) {
  .hero-actions {
    flex-direction: column;
    align-items: stretch;
  }
  
  .btn-primary,
  .btn-secondary {
    justify-content: center;
  }
}

/* Section Articles */
.section-articles {
  padding: 60px 0;
}

.section-articles h2 {
  font-size: 1.875rem;
  font-weight: 700;
  color: #1e3a8a;
  margin: 0 0 32px 0;
  text-align: center;
}



/* Carte article - même style que .form-article */

.card-article:hover {
  transform: translateY(-2px);
  box-shadow: 0 20px 28px -12px rgba(0,0,0,0.12);
}



.card-article h3 {
  font-size: 1.25rem;
  font-weight: 600;
  color: #111;
  margin: 0 0 12px 0;
  line-height: 1.4;
}

.card-extrait {
  color: #4b5563;
  line-height: 1.6;
  margin: 0 0 20px 0;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.875rem;
}

.card-auteur {
  color: #6b7280;
}

.card-lien {
  color: #3b82f6;
  font-weight: 500;
  text-decoration: none;
}

.card-lien:hover {
  text-decoration: underline;
}

/* CTA */
.cta {
  margin: 60px 0;
  padding: 48px;
  text-align: center;
  border: 1px solid #bfdbfe;
  border-radius: 12px;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.cta h2 {
  font-size: 1.875rem;
  font-weight: 700;
  color: #1e3a8a;
  margin: 0 0 12px 0;
}

.cta p {
  color: #1e40af;
  margin: 0 0 24px 0;
  font-size: 1.125rem;
}

/* Responsive */
@media (max-width: 768px) {
  .hero-content h1 {
    font-size: 2.25rem;
  }
  .hero {
    padding: 60px 0 40px 0;
  }
  .hero-actions {
    flex-direction: column;
  }
  .btn-primary, .btn-secondary {
    width: 100%;
  }
}
</style>