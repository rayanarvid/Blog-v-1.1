const Post = require('../models/PostModel');

exports.getPosts = (req, res) => {
  Post.getAllPosts((err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.getPost = (req, res) => {
  Post.getPostById(req.params.id, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results[0]);
  });
};

exports.createPost = (req, res) => {
  Post.createPost(req.body, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Article créé' });
  });
};

exports.updatePost = (req, res) => {
  Post.updatePost(req.params.id, req.body, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Article modifié' });
  });
};

exports.deletePost = (req, res) => {
  Post.deletePost(req.params.id, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Article supprimé' });
  });
};