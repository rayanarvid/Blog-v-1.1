const db = require('../config/db');

exports.getAllPosts = (callback) => {
  db.query('SELECT * FROM posts ORDER BY created_at DESC', callback);
};

exports.getPostById = (id, callback) => {
  db.query('SELECT * FROM posts WHERE id_article = ?', [id], callback);
};

exports.createPost = (data, callback) => {
  db.query(
    'INSERT INTO article (id_article, titre , contenu, id_utilisateur, id_categorie) VALUES (?, ?, ?, ?, ?)',
    [data.title, data.content],
    callback
  );
};

exports.updatePost = (id, data, callback) => {
  db.query(
    'UPDATE posts SET title = ?, content = ? WHERE id = ?',
    [data.title, data.content, id],
    callback
  );
};

exports.deletePost = (id, callback) => {
  db.query('DELETE FROM posts WHERE id = ?', [id], callback);
};