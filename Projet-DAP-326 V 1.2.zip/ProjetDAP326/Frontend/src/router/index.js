import Home from '../pages/Home.vue'
import CreatePost from '../pages/CreatePost.vue'
import LoginUser from '../pages/LoginUser.vue'

export const routes = [
  { path: '/',
     component: Home,
     meta: {title: 'Accueil - Mon Blog'}
  },
  { path: '/create', 
    component: CreatePost,
    meta: {title: 'Créer un article - Mon Blog'}
  },
  { path: '/login', 
    component: LoginUser,
    meta: {title: 'Se connecter - Mon Blog'}
  }
];