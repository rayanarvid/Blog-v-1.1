<template>
    <div class="cardre">
         <!-- <img :src="imageSrc" alt="Image de l'article" class="card-image" v-if="imageSrc"/> -->    

      <div class="card-content">
        <h5> {{ titre }} </h5>
        <p> {{ contenu }} </p>
      </div>

      <div class="card-footer">
        <button class="btn-like"> Liker </button>
        <button class="btn-read"> Lire la suite </button>
      </div>
    </div>
</template>

<script setup>
  
  defineProps({
    titre: String,
    contenu: String,
    auteur: String,
    categorie: String,
    nombrevue: Number
  })

</script>

<style scoped>
  
  .cardre {
            border: 2px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            background: #fff;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px 20px 20px;
        }

        .btn-like , .btn-read {
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }

        .btn-like {
            background: #f3f4f6;
            color:  #111;
        }

        .btn-like:hover {
            background: #fee2e2;
            color: #dc2626;
        }

        .btn-read {
            background: #3b82f6;
            color: white;
        }

        .btn-read:hover {
            background: #2563eb;
        }

        .cardre h5 {
            margin: 2px 0 12px 0;
            font-size: 1.3rem;
        }

        .cardre p {
            color: #555;
            line-height: 1.6;
            margin: 0;
        }

        .card-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }
</style>