const Post = require('../models/PostModel');

exports.getPosts = (req, res) => {
  Post.getAllPosts((err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.createPost = (req, res) => {
  console.log('BODY reçu:', req.body); // Debug: Affiche le contenu de req.body

  const {
    titre,
    contenu,
  } = req.body;

  if (!titre || !contenu) {
    return callback(new Error('Les champs titre et contenu sont requis'));
  }

  Post.create({titre, contenu, nombrevue, id_utilisateur, id_categorie},
     (err, results) => {
    if (err) {
      console.error('Erreur SQL:', err); // Debug: Affiche l'erreur SQL
       return res.status(500).json(err); 
      }
    res.status(201).json({ message: 'Article créé avec succès', id: results.insertId });
  });
};



