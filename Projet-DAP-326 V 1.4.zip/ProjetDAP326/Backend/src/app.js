const express = require('express');
const cors = require('cors');
const postRoutes = require('./routes/PostRoutes');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api', postRoutes);

app.get('/', (req, res) => {
    res.send('API backend fonctionne')
})

module.exports = app;