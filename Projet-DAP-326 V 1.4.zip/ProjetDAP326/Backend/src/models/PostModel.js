const db = require('../config/db');

exports.getAllPosts = (callback) => {
  db.query('SELECT * FROM posts ORDER BY created_at DESC', callback);
};

exports.create = (data, callback) => {

  const {
    titre,
    contenu,
    nombrevue,
    id_utilisateur,
    id_categorie
  } = data;

  db.query(
    'INSERT INTO article (id_article, nom , contenu, nombre_vue, date_publication, id_utilisateur, id_categorie) VALUES (?, ?, ?, ?, NOW(), ?, ?)',
    [data.id_article, data.nom, data.contenu, data.nombre_vue, data.id_utilisateur, data.id_categorie],
    (err, results) => {
      if (err) return callback(err, null);
      callback(null, results);
    }
  );
};
