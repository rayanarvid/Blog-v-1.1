const app = require('./src/app');

app.listen(3000, () => {
  console.log('Backend lancé sur http://localhost:3000');
});