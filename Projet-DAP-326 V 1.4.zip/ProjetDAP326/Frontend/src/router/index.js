import Home from '../pages/Home.vue'
import CreatePost from '../pages/CreatePost.vue'
import LoginUser from '../pages/LoginUser.vue'
import SignIn from '../composants/SignIn.vue'

export const routes = [
  { path: '/',
     component: Home,
     meta: {title: 'Accueil - Mon Blog'}
  },
  { path: '/create', 
    component: CreatePost,
    meta: {title: 'Créer un article - Mon Blog'}
  },
  { path: '/login', 
    component: LoginUser,
    meta: {title: 'Se connecter - Mon Blog'}
  },
  { path: '/signIn', 
    component: SignIn,
    meta: {title: 'S \'inscrire - Mon Blog'}
  }
];