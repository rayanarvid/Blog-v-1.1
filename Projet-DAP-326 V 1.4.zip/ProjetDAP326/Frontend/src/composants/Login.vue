<template>
    <form class="form-article" @submit.prevent="handleLogin">
                <h2> Se Connecter </h2>

                <div class="form-group">
                    <label for=""> Email </label>
                    <input type="email" placeholder="tonemail@gmail.com" v-model="form.email" required>
                </div>

                <div class="form-group">
                    <label for=""> Mot de passe </label>
                    <input type="password" placeholder="******" v-model="form.password" required>
                </div>

                <div class="form-group-row">
                    <label class="checkbox"> 
                      <input type="checkbox" v-model="form.rememberMe">
                      Se souvenir de moi
                    </label>
                    <a href="#"> Mot de passe oublié ? </a>
                </div>

                <button class="btn-primary">
                    Se connecter
                </button>

                <p class="switch-auth">
                    Pas encore de compte ?
                    <RouterLink to="/signIn"> S'inscrire </RouterLink>
                </p>
            </form>
</template>

<script setup>
   import { reactive,ref} from 'vue'
   import {useRouter} from 'vue-router'
   import api from '../services/api.js'

   const router = useRouter()

   const form = reactive({
    email: '',
    password: '',
    rememberMe: false
   })

   const handleLogin = async () => {

    try{
        const reponse = await api.post("/login", form)

        localStorage.setItem('token', reponse.data.token)
        localStorage.setItem('user', JSON.stringify(reponse.data.user))

        console.log('Utilisateur connecté avec succès', reponse.data)
        alert('Utilisateur connecté avec succès')
        router.push('/')

     } catch (error) {
        console.error(error)
        alert("Erreur de connexion")
        
     }
     
   }

</script>

<style scoped>
   .form-article {
                max-width: 480Px;
                width: 100%;
                margin: 2rem auto;
                margin-top: 100px;
                margin-bottom: 30px;
                padding: 2.5rem;
                border: 1px solid rgb(0, 0, 0.04);
                border-radius: 28px;
                background: #FFFFFF;
                box-shadow: 0 20px 35px -12px rgba(0, 0, 0, 0.08);
                transition: all 0.2s ease;
                font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }

    .form-article:hover {
        box-shadow: 0 25px 40px -14px rgba(0, 0, 0, 0.12);
    }

            .form-article h2 {
                font-size: 1.8rem;
                font-weight: 700;
                color: #1A1A2E;
                margin-bottom: 1.5rem;
                letter-spacing: -0.3px;
                position: relative;
                display: inline-block;
            }

            .form-article h2::after {
                content: '';
                position: absolute;
                bottom: -8px;
                left: 0;
                width: 50px;
                height: 3px;
                background: linear-gradient(90deg, #8B5CF6, #C4B5FD);
                border-radius: 3px;
            }

            .form-group {
                margin-bottom: 1.5rem;
            }

            .form-group label {
                display: block;
                font-size: 0.85rem;
                margin-bottom: 0.5rem;
                font-weight: 600;
                color: #334155;
                letter-spacing: -0.2px;
            }

            .form-group input[type="email"],
            .form-group input[type="password"] {
                width: 100%;
                padding: 0.9rem 1rem;
                border: 1px solid #E2E8F0;
                border-radius: 16px;
                font-size: 0.9rem;
                font-family: inherit;
                transition: all 0.2s ease;
                background: #F8FAFE;
                color: #1A1A2E;
            }

            .form-group input:focus {
                outline: none;
                border-color: #8B5CF6;
                background-color: #FFFFFF;
                box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
            }

            .form-group input::placeholder {
                color: #A0AEC0;
                font-weight: 400;
            }

            .form-group-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 2rem;
                flex-wrap: wrap;
                gap: 0.8rem;
            }

            .checkbox {
                display: flex;
                align-items: center;
                gap: 0.6rem;
                cursor: pointer;
                font-size: 0.85rem;
                color: #475569;
            }

            .checkbox input[type="checkbox"] {
                width: 18px;
                height: 18px;
                accent-color: #8B5CF6;
                cursor: pointer;
                margin: 0;
            }

            .form-group-row a {
                color: #6D28D9;
                text-decoration: underline;
            }

            .form-group-row a:hover {
                color: #6D28D9;
                text-decoration: underline;
            }

            .btn-primary {
                width: 100%;
                padding: 0.9rem;
                border: none;
                border-radius: 48px;
                font-weight: 600;
                background: linear-gradient(135deg, #8B5CF6, #6D28D9);
                color: white;
                cursor: pointer;
                transition: all 0.2s ease;
                font-family: inherit;
                letter-spacing: -0.2px;
                box-shadow: 0 4px 12px rgba(139, 92, 246, 0.25);
                margin-bottom: 1.5rem;
            }

            .btn-primary:hover {
                background: linear-gradient(135deg, #7C3AED, #5B21B6);
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(139, 92, 246, 0.35);
            }

            .btn-primary:active {
                transform: translateY(0);
            }

            .switch-auth {
                text-align: center;
                margin: 0;
                color: #64728b;
                font-size: 0.85rem;
                padding-top: 1rem;
                border-top: 1px solid #F0F2F5;
            }

            .switch-auth a {
                color: #8B5CF6;
                font-weight: 600;
                text-decoration: none;
            }

            .switch-auth a:hover {
                color: #6D28D9;
                text-decoration: underline;
            }
</style>