<template>
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-section">
        <div class="logo">
          <span class="logo-text">GUIFO RAYAN</span>
        </div>
        <p class="description">Partagez vos idées et découvrez des articles inspirants.</p>
      </div>

      <div class="footer-section">
        <h3>Liens utiles</h3>
        <ul>
          <li><a href="#">Catégorie</a></li>
          <li><a href="#">Créer</a></li>
          <li><a href="#">Profil</a></li>
        </ul>
      </div>

      <div class="footer-section">
        <h3>Légal</h3>
        <ul>
          <li><a href="#">Mentions légales</a></li>
          <li><a href="#">Politique de confidentialité</a></li>
          <li><a href="#">CGU</a></li>
        </ul>
      </div>

      <div class="footer-section">
        <h3>Suivez-nous</h3>
        <div class="social-links">
          <a href="#" class="social-link">Twitter</a>
          <a href="#" class="social-link">LinkedIn</a>
          <a href="#" class="social-link">GitHub</a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>&copy; 2026 Blog - Tous droits réservés</p>
    </div>
  </footer>
</template>

<script setup>

</script>

<style scoped>
.footer {
  background: rgba(10, 10, 20, 0.95);
  backdrop-filter: blur(16px);
  border-top: 1px solid rgba(255, 255, 255, 0.08);
  font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  margin-top: 4rem;
}

.footer-container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 3rem 2rem 2rem 2rem;
  display: flex;
  justify-content: space-between;
  gap: 3rem;
  flex-wrap: wrap;
}

.logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.logo-img {
  width: 32px;
  height: 32px;
}

.logo-text {
  font-size: 1.5rem;
  font-weight: bold;
  color: #CBD5E1;
}

.description {
  color: #CBD5E1;
  line-height: 1.5;
}

.footer-section {
  flex: 1;
  min-width: 160px;
}

.footer-section h3 {
  font-size: 0.9rem;
  color: #F1F5F9;
  font-weight: 600;
  letter-spacing: 0.3px;
  text-transform: uppercase;
  margin-bottom: 1.2rem;
  position: inherit;
  display: inline-block;
}

.footer-section h3::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: 0;
  width: 32px;
  height: 2px;
  background: linear-gradient(90deg, #A78BFA, #8B5CF6);
  border-radius: 2px;
}

.footer-section ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.footer-section ul li {
  margin-bottom: 0.7rem;
}

.footer-section ul li a {
  text-decoration: none;
  color: #94A3B8;
  font-size: 0.85rem;
  transition: all 0.2s ease;
  display: inline-block;
}

.footer-section a:hover {
  color: #C4B5FD;
  transform: translateX(4px);
}

.social-links {
  display: flex;
  flex-direction: column;
  gap: 0.7rem;
}

.social-link {
  text-decoration: none;
  color: #94A3B8;
  font-size: 0.85rem;
  transition: all 0.2s ease;
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
}

.social-link::before {
  content: '>';
  font-size: 0.7rem;
  color: #8B5CF6;
  opacity: 0;
  transition: opacity 0.2s ease, transform 0.2s ease;
}

.social-link:hover::before {
  opacity: 1;
}

.social-link:hover {
  color: #C4B5FD;
  transform: translateX(4px);
}

.footer-bottom {
  text-align: center;
  padding: 1.5rem 2rem;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

.footer-bottom p {
  color: #64748B;
  font-size: 0.75rem;
  letter-spacing: 0.3px;
  margin: 0;
}
</style>