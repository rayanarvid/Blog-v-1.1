<template>
    <div class="cardre">
         <!-- <img :src="imageSrc" alt="Image de l'article" class="card-image" v-if="imageSrc"/> -->    

      <div class="card-content">
        <h5> {{ titre }} </h5>
        <p> {{ contenu }} </p>
      </div>

      <div class="card-footer">
        <button class="btn-like"> Liker </button>
        <button class="btn-read"> Lire la suite </button>
      </div>
    </div>
</template>

<script setup>
  
  defineProps({
    titre: String,
    contenu: String,
    auteur: String,
    categorie: String,
    nombrevue: Number
  })

</script>

<style scoped>
  
  .cardre {
            border: 1px solid #eaedf2;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            background: #ffffff;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            overflow: hidden;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .card-footer {
            display: flex;
            gap: 24px;
            margin-top: 8px;
            border-top: 1px solid #eef2f6;
            padding-top: 20px;
        }

        .btn-like , .btn-read {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            background: none;
            border: none;
            padding: 6px 12px 6px 10px;
            cursor: pointer;
            color: #2c3e50;
            transition: color 0.2s;
            font-family: inherit;
            border-radius: 6px;
        }

        .btn-like {
            color:  #e11d48;
        }

        .btn-like:hover {
            color: #ffff;
            background: #e11d48;
        }

        .btn-read {
            background: #3b82f6;
        }

        .btn-read:hover {
            color: #ffff;
            background: #2563eb;
        }

        .cardre h5 {
            margin: 0 0 8px 0;
            font-size: 1.65rem;
            font-weight: 700;
            color: #11181c;
            letter-spacing: -0.3px;
        }

        .cardre p {
            font-size: 0.95rem;
            color: #5b6871;
            line-height: 1.45;
            margin-bottom: 24px;
            border-left: 3px solid #3b82f6;
            padding-left: 12px;
        }

        .card-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }
</style>