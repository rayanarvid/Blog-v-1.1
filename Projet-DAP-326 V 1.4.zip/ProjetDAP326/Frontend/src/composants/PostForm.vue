<template>
    <form  class="form-article" @submit.prevent="handleSubmit">
            <h2> {{ titreForm }} </h2>

            <div class="form-group">
                <label> Titre de l'article </label>
                <input type="text" placeholder="Ex: Comment dribbler" v-model="form.titre" required>
                <div v-if="form.titre.length === 0" :style="{color: 'red', fontSize: '12px' }">Le titre est requis</div>
                <div v-else :style="{color: 'green', fontSize: '12px'}">Titre valide</div>
            </div>

            <!--<div class="form-group">
                <label> Image de couverture </label>
                <input type="file" accept="image/*" @change="handleImageChange" required>
                <small v-if="imagePreview" :style="{color : 'green'}"> Image sélectionnée </small>
                <small v-else :style="{color : 'gray'}"> JPG, PNG , 1200x600px recommandé </small>
            </div>-->

            <div class="form-group">
                <label> Categorie </label>
                <select v-model="form.categorie" required>
                    <option v-for="cat in categories" :key="cat.value" :value="cat.value">
                        {{ cat }}
                    </option>
                </select>
            </div>

            <div class="form-group">
                <label> Contenu </label>
                <textarea id="contenu" placeholder="Redigez ton article ici..." v-model="form.contenu" required></textarea>
                <div v-if="form.contenu.length === 0" :style="{color: 'red', fontSize: '12px' }">Le contenu est requis</div>
                <div v-else :style="{color: 'green', fontSize: '12px'}">Contenu valide</div>
            </div>

            <div class="form-actions">
                <button type="button" class="btn-secondary" @click="handleCancel"> Annuler </button>
                <button type="submit" class="btn-primary" > Publier l'article </button>
            </div>
        </form>
</template>

<script setup>
   import {ref,reactive} from 'vue'
   import {useRouter} from 'vue-router'
   import api from '../services/api.js'

   const router = useRouter()

   const props = defineProps({
    titreForm: {
        type: String,
        default: 'Créer un nouvel article'
    },
    submitLabel: {
        type: String,
        default: 'Publier'
    }
   })

   const categories = ref(['Science','Ecole','Sport','Musique', 'Informatique'])
   const loading = ref(false)

   const form = reactive({
    titre: '',
    contenu: '',
    nombrevue:0,
    id_utilisateur: 1,
    id_categorie: 1
   })

   /*const handleImageChange = (event) => {
    const file = event.target.files[0]
    if (file) {
        form.image = file
        imagePreview.value = URL.createObjectURL(file)
    }
   }*/

   const handleSubmit = async () => {
    loading.value = true
    try {
        const reponse = await api.post('/posts', form.value)
        console.log('Article créé avec succès', reponse.data)
        alert('Article créé avec succès')
        router.push('/')
    } catch (error) {
        alert('Erreur lors de la création de l\'article. Vérifie la console pour plus de détails.')
        console.error('Erreur lors de la création de l\'article :', error)
        console.error('URL appelée :', error.config.url)
        console.error('Status :', error.response?.status)
        console.error('Message backend :', error.response?.data)
    } finally {
        loading.value = false
    }
   }

   const handleCancel = () => {
    alert('Formulaire annulé')
    router.push('/')
   }
</script>

<style scoped>
   
   .form-article {
                max-width: 800px;
                width: 100%;
                margin: 2rem auto;
                margin-top: 85px;
                padding: 2.5rem;
                margin-bottom: 30px;
                border: 1px solid rgba(0, 0, 0, 0.04);
                border-radius: 28px;
                transition: all 0.2s ease;
                background: #FFFFFF;
                box-shadow: 0 20px 35px -12px  rgba(0, 0, 0, 0.08);
                font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            }

            .form-article:hover {
                box-shadow: 0 25px 40px -14px rgba(0, 0, 0, 0.12);
            }

            .form-article h2 {
                font-size: 1.8rem;
                font-weight: 700;
                color: #1A1A2E;
                margin-bottom: 2rem;
                letter-spacing: -0.3px;
                position: relative;
                display: inline-block;
            }

            .form-article h2::after {
                content: '';
                position: absolute;
                bottom: -8px;
                left: 0;
                width: 50px;
                height: 3px;
                background: linear-gradient(90deg, #8B5CF6, #C4B5FD);
                border-radius: 3px;
            }

            .form-group {
                margin-bottom: 1.8rem;
            }

            .form-group label {
                display: block;
                font-size: 0.85rem;
                margin-bottom: 0.5rem;
                font-weight: 600;
                color: #334155;
                letter-spacing: -0.2px;
            }

            .form-group input[type="text"],
            .form-group input[type="file"],
            .form-group select,
            .form-group textarea {
                width: 100%;
                padding: 0.9rem 1rem;
                border: 1.5px solid #E2E8F0;
                border-radius: 16px;
                font-size: 0.9rem;
                font-family: inherit;
                transition: all 0.2s ease;
                background: #F8FAFE;
                color: #1A1A2E;
            }

            .form-group input:focus,
            .form-group select:focus,
            .form-group textarea:focus {
                outline: none;
                border-color: #8B5CF6;
                background: #FFFFFF;
                box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1);
            }

            .form-group input::placeholder,
            .form-group input::placeholder {
                color: #A0AEC0;
                font-weight: 400;
            }

            .form-group textarea {
                min-height: 200px;
                resize: vertical;
            }

            .form-group select {
                cursor: pointer;
                appearance: none;
                background-image: url("data:image/svg+xml,%3Csvg xmlns=''");
                background-repeat: no-repeat;
                background-position: right 1rem center;
                background-size: 16px;
            }

            .form-group small {
                display: block;
                margin-top: 4px;
                color: #6b7280;
                font-size: 0.875rem;
            }

            .form-actions {
                display: flex;
                justify-content: flex-end;
                gap: 1rem;
                margin-top: 2rem; 
            }

            .btn-primary {
                background: linear-gradient(135deg, #8B5CF6, #6D28D9);
                border: none;
                padding: 0.9rem 2rem;
                border-radius: 48px;
                font-weight: 600;
                font-size: 0.9rem;
                cursor: pointer;
                transition: all 0.2s ease;
                font-family: inherit;
                letter-spacing: -0.2px;
                box-shadow: 0 4px 12px rgba(139, 32, 246, 0.25);
                color: white;
            }

            .btn-primary:hover {
                background: linear-gradient(135deg, #7C3AED, #5B21B6);
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(139, 32, 246, 0.35);
            }

            .btn-primary:active {
                transform: translateY(0);
            }

            .btn-secondary {
                background: transparent;
                border: 1.5px solid #E2E8F0;
                padding: 0.9rem 2rem;
                border-radius: 48px;
                font-weight: 600;
                font-size: 0.9rem;
                cursor: pointer;
                transition: all 0.2s ease;
                font-family: inherit;
                color: #64748B;
            }

            .btn-secondary:hover {
                border-color: #8B5CF6;
                color: #8B5CF6;
                background: #F8F4FF;
            }
</style>