<template>
  <NavBar/>
  <RouterView/>
  <pied/>
</template>

<script setup>
   import NavBar from './composants/NavBar.vue'
   import pied from './composants/Footer.vue'
</script>

<style scoped></style>
