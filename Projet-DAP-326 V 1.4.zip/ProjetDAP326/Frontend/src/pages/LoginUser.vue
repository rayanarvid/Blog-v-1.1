<template>
    <Login/>
</template>

<script setup>
   import Login from '../composants/Login.vue'
</script>