<template>
    
    <div class="page-home">
    

    <main class="container">
      <!-- Section Hero -->
      <section class="hero">
        <div class="hero-content">
          <h1> Partage tes idées au monde </h1>
          <p class="hero-subtitle">
            Crée, publie et découvre des articles inspirants. Rejoins une communauté de passionnés.
          </p>
          <div class="hero-actions">
            <RouterLink to="/create" class="btn-primary">
              Créer un article
            </RouterLink>
            <RouterLink to="/" class="btn-secondary">
              Explorer
            </RouterLink>
          </div>
        </div>
      </section>

      <!-- Section Articles récents -->
      <section class="section-articles">
        <h2>Articles récents</h2>
        <div class="grid-articles">
          <div v-for="article in articles" :key="article.id" class="card-article">
            <PostCard :titre="article.titre" :contenu="article.extrait" :auteur="article.auteur" :categorie="article.categorie" :nombrevue="article.nombrevue"/>
          </div>
        </div>
      </section>

      <!-- Section CTA -->
      <section class="cta">
        <h2>Prêt à écrire ?</h2>
        <p>Lance-toi et partage ton premier article avec la communauté.</p>
        <RouterLink to="/create" class="btn-primary">Commencer</RouterLink>
      </section>
    </main>

  </div>
</template>

<script setup>
   import { ref } from 'vue'
   import PostCard from '../composants/PostCard.vue'
   
       // Données de test - remplace par ton appel API
     const articles = ref([
       {
         id: 1,
         titre: 'Comment Vue 3 a changé ma façon de coder',
         extrait: 'La Composition API est une révolution. Voici pourquoi je ne reviendrai jamais en arrière...',
         auteur: 'Sarah K.',
         categorie: 'Dev',
          nombrevue: 120
       },
       {
         id: 2,
         titre: 'Design minimaliste : moins mais mieux',
         extrait: '3 principes pour créer des interfaces épurées qui convertissent vraiment...',
         auteur: 'Marc D.',
         categorie: 'Design',
          nombrevue: 85
       },
       {
         id: 3,
         titre: 'Mon setup télétravail en 2026',
         extrait: 'Chaise, écran, clavier : mon guide complet après 4 ans de remote...',
         auteur: 'Lina T.',
         categorie: 'Lifestyle',
          nombrevue: 200
       }
     ])

     
</script>

<style scoped>
  .page-home {
  min-height: 100vh;
}

.container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Hero */
.hero {
  background: linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
  padding: 4rem 2rem;
  border-bottom: 1px solid #e0e7ff;
  text-align: center;
  margin-top: 90px;
}

.hero-content {
  max-width: 800px;
  margin: 0 auto;
}

.hero-content h1 {
  font-size: 3rem;
  font-weight: 800;
  color: #0f172a;
  margin: 0 0 1rem 0;
  letter-spacing: -0.02rem;
  line-height: 1.2;
}

.hero-subtitle {
  font-size: 1.2rem;
  color: #334155;
  max-width: 560px;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 2rem;
  line-height: 1.5;
}

.hero-actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
  margin-bottom: 2.5rem;
}

/* Boutons - même style que tes formulaires */
.btn-primary, .btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0.8rem 1.8rem;
  border-radius: 48px;
  font-weight: 600;
  font-size: 0.95rem;
  cursor: pointer;
  transition: all 0.2s ease;
  text-decoration: none;
  display: inline-block;
}

.btn-primary {
  background: #4f46e5;
  color: white;
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
}

.btn-primary:hover {
  background: #2563eb;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
}

.btn-secondary {
  background: white;
  color: #4338ca;
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
}

.btn-secondary:hover {
  background: #faf5ff;
  border-color: #4f46e5;
  transform: translateY(-2px);
}

/* Section Articles */
.section-articles {
  padding: 60px 0;
}

.section-articles h2 {
  font-size: 1.875rem;
  font-weight: 700;
  color: #1e3a8a;
  margin: 0 0 32px 0;
  text-align: center;
}



/* Carte article - même style que .form-article */

.card-article:hover {
  transform: translateY(-2px);
  box-shadow: 0 20px 28px -12px rgba(0,0,0,0.12);
}



.card-article h3 {
  font-size: 1.25rem;
  font-weight: 600;
  color: #111;
  margin: 0 0 12px 0;
  line-height: 1.4;
}

.card-extrait {
  color: #4b5563;
  line-height: 1.6;
  margin: 0 0 20px 0;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.875rem;
}

.card-auteur {
  color: #6b7280;
}

.card-lien {
  color: #3b82f6;
  font-weight: 500;
  text-decoration: none;
}

.card-lien:hover {
  text-decoration: underline;
}

/* CTA */
.cta {
  margin: 60px 0;
  padding: 48px;
  text-align: center;
  border: 1px solid #bfdbfe;
  border-radius: 12px;
  background: #fff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.cta h2 {
  font-size: 1.875rem;
  font-weight: 700;
  color: #1e3a8a;
  margin: 0 0 12px 0;
}

.cta p {
  color: #1e40af;
  margin: 0 0 24px 0;
  font-size: 1.125rem;
}

/* Responsive */
@media (max-width: 768px) {
  .hero-content h1 {
    font-size: 2.25rem;
  }
  .hero {
    padding: 60px 0 40px 0;
  }
  .hero-actions {
    flex-direction: column;
  }
  .btn-primary, .btn-secondary {
    width: 100%;
  }
}
</style>