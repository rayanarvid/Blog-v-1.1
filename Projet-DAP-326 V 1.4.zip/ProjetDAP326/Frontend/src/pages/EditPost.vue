<template>
    <PostForm @submit="" @cancel=""/>
</template>

<script setup>
   import PostForm from '../composants/PostForm.vue'
</script>