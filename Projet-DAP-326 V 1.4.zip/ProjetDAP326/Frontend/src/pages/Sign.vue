<template>
    <SignIn/>
</template>

<script setup>
   import SignIn from '../composants/SignIn.vue'
</script>