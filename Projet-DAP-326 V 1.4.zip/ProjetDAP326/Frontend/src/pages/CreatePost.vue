<template>
    <PostForm titreForm="Créer un nouvel article"/>
</template>

<script setup>
  import PostForm from '../composants/PostForm.vue'
</script>