import { createApp } from 'vue'
import App from './App.vue'
import { createRouter, createWebHistory } from 'vue-router'
import { routes } from './router/index'

const router = createRouter({
  history: createWebHistory(),
  routes
});

router.afterEach((to) => {
    document.title = to.meta.title
})

createApp(App).use(router).mount('#app')
